package controller;

import model.PIM.*;
import org.junit.Test;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.Collection;
import java.util.Scanner;

public class PIMManager {
    private static PIMManager instance = null;
    private PIMCollection logs = new PIMCollection();

    public void LoadEntity(Connection conn,String tableName) throws SQLException {
        Statement statement = conn.createStatement();
        ResultSet rs = statement.executeQuery("select * from "+tableName);
        int c = rs.getMetaData().getColumnCount();
        String[] as = new String[10];
        while(rs.next()){
            for (int i=1;i<=c;i++) {
                as[i] = (rs.getString(i));
            }
            PIMEntity e =null;
            switch (tableName){
                case "Appointment": e= new PIMAppointment();break;
                case "Contact": e= new PIMContact();break;
                case "Note": e= new PIMNote();break;
                case "Todo": e= new PIMTodo();break;
            }
            assert e != null;
            e.fromString(as);
            logs.add(e);
        }
        rs.close();
    }

    public void loadPIM(){
        try {
            Connection conn = PoolManager.getConnection();
            if(conn != null){
                LoadEntity(conn,"Appointment");
                LoadEntity(conn,"Contact");
                LoadEntity(conn,"Note");
                LoadEntity(conn,"Todo");
            }
            PoolManager.freeConnection(conn);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void insertPIM(String sql){
        try {
            Connection conn = PoolManager.getConnection();
            Statement statement = conn.createStatement();
            statement.executeUpdate(sql);
            statement.close();
            PoolManager.freeConnection(conn);
            System.out.println("插入成功");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test(){
        try {
            Connection conn = PoolManager.getConnection();
            if(conn != null){
                Statement statement = conn.createStatement();
                ResultSet rs = statement.executeQuery("select * from log");
                int c = rs.getMetaData().getColumnCount();
                while(rs.next()){
                    System.out.println();
                    for(int i=1;i<=c;i++){
                        System.out.print(rs.getObject(i));
                    }
                }
                rs.close();
            }
            PoolManager.freeConnection(conn);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static PIMManager getInstance() {
        if (instance==null)
        {
            instance = new PIMManager();
            instance.loadPIM();
        }
        return instance;
    }

//    public void List() {
//
//    }

    public void CreateContact(String first_name,String last_name,String email_address,String pri,String owner ){
        PIMEntity e= new PIMContact(first_name, last_name, email_address, pri,owner);
        logs.add(e);
        insertPIM(e.toString());
    }

    public void CreateNote(String text,String pri,String owner){
        PIMEntity e = new PIMNote(text, pri,owner);
        logs.add(e);
        insertPIM(e.toString());

    }
    public void CreateAppointment(String date,String des,String pri,String owner){
        PIMEntity e= new PIMAppointment(date, des, pri,owner);
        logs.add(e);
        insertPIM(e.toString());
    }
    public void CreateTodo(String date,String item,String Priority,String owner){
        PIMEntity  e = new PIMTodo(date, item, Priority,owner);
        logs.add(e);
        insertPIM(e.toString());
    }

    public Collection<PIMEntity> getCollection(String s) throws Exception {
        Collection<PIMEntity> c;
        switch (s) {
            case "todo": {
                c = logs.getTodos();
                for (PIMEntity e : c) {
                    System.out.println(e.toString());
                }
                break;
            }
            case "note": {
                c = logs.getNotes();
                for (PIMEntity e : c) {
                    System.out.println(e.toString());
                }
                break;
            }
            case "contact": {
                c = logs.getContacts();
                for (PIMEntity e : c) {
                    System.out.println(e.toString());
                }
                break;
            }
            case "appointment": {
                c = logs.getAppointments();
                for (PIMEntity e : c) {
                    System.out.println(e.toString());
                }
                break;
            }
            default:{
                throw new Exception("输入错误");
            }
        }
        return c;
    }

    public Collection<PIMEntity> getCollectionByDate(String tt) throws ParseException {
        return logs.getItemsForDate(DateOperation.sdf.parse(tt));
    }

    public void main(String[] args) throws IOException, ParseException {
        //PIMManager.Start();
        PoolManager.startPool();
        loadPIM();
        Scanner cin = new Scanner(System.in);
        while (true) {
            System.out.println("Welcome to PIM.\n" +
                    "---Enter a command (suported commands are List Create Save Load Quit Query)---");
            String q = cin.next();
            switch (q) {
                case "List": {
                    System.out.printf("There are %d items.\n", logs.size());
                    for (PIMEntity e : logs) {
                        System.out.println(e.toString());
                    }
                    break;
                }
//                case "Create": {
//                    System.out.println("Enter an item type ( todo, note, contact or appointment )");
//                    String t = cin.next();
//                    PIMEntity e = null;
//                    switch (t) {
//                        case "todo": {
//                            System.out.println("Enter date for todo item: ");
//                            String date = cin.next();
//                            System.out.println("Enter Priority for todo item: ");
//                            String Priority = cin.next();
//                            System.out.println("Enter item for todo item: ");
//                            cin.nextLine();
//                            String item = cin.nextLine();
//                            e = new PIMTodo(date, item, Priority);
//                            //System.out.println(e);
//                            break;
//                        }
//                        case "note": {
//                            System.out.println("Enter Priority for todo text: ");
//                            String pri = cin.next();
//                            System.out.println("Enter text for todo item: ");
//                            String text = cin.next();
//                            e = new PIMNote(text, pri);
//                            break;
//                        }
//                        case "appointment": {
//                            System.out.println("Enter date for todo item: ");
//                            String date = cin.next();
//                            System.out.println("Enter Priority for todo item: ");
//                            String pri = cin.next();
//                            System.out.println("Enter description for todo item: ");
//                            String des = cin.next();
//                            e = new PIMAppointment(date, des, pri);
//                            break;
//                        }
//                        case "contact": {
//                            System.out.println("Enter first_name for todo item: ");
//                            String first_name = cin.next();
//                            System.out.println("Enter last_name for todo item: ");
//                            String last_name = cin.next();
//                            System.out.println("Enter email_address for todo item: ");
//                            String email_address = cin.next();
//                            System.out.println("Enter pri for todo item: ");
//                            String pri = cin.next();
//                            e = new PIMContact(first_name, last_name, email_address, pri);
//                            break;
//                        }
//                    }
//                    System.out.println(e);
//                    logs.add(e);
//                    insertPIM(e.toString());
//                    System.out.println(logs.size());
//                    break;
//                }
                case "Query": {
                    System.out.println("Enter an item type ( todo, note, contact or appointment ) " +
                            "or Date(The format is \"yyyy-MM-dd\")");
                    String t = cin.next();
                    switch (t) {
                        case "todo": {
                            Collection<PIMEntity> c = logs.getTodos();
                            for (PIMEntity e : c) {
                                System.out.println(e.toString());
                            }
                            break;
                        }
                        case "note": {
                            Collection<PIMEntity> c = logs.getNotes();
                            for (PIMEntity e : c) {
                                System.out.println(e.toString());
                            }
                            break;
                        }
                        case "contact": {
                            Collection<PIMEntity> c = logs.getContacts();
                            for (PIMEntity e : c) {
                                System.out.println(e.toString());
                            }
                            break;
                        }
                        case "appointment": {
                            Collection<PIMEntity> c = logs.getAppointments();
                            for (PIMEntity e : c) {
                                System.out.println(e.toString());
                            }
                            break;
                        }
                        case "Date": {
                            System.out.println("Please input the certain date:");
                            String tt = cin.next();
                            Collection<PIMEntity> c = logs.getItemsForDate(DateOperation.sdf.parse(tt));
                            for(PIMEntity e:c){
                                System.out.println(e.toString());
                            }
                            break;
                        }
                        default:
                            break;
                    }
                    break;
                }
                case "Quit": {
                    return;
                }
                default: {
                    System.out.println("Input error,plz try again.");
                    break;
                }
            }
        }

    }
}
